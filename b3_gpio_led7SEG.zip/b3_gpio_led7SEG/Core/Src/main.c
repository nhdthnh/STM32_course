/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

//define các chân sử dụng điều khiển LED 595
#define DATA_HIGH HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_SET)
#define DATA_LOW HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_RESET)
#define CLK_HIGH HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_SET)
#define CLK_LOW HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_RESET)
#define LAT_HIGH HAL_GPIO_WritePin(LAT_GPIO_Port, LAT_Pin, GPIO_PIN_SET)
#define LAT_LOW HAL_GPIO_WritePin(LAT_GPIO_Port, LAT_Pin, GPIO_PIN_RESET)

void truyen8bit(uint8_t data)
{
	uint8_t temp = 0,i;

	for(i=0;i<8;i++)
	{
		CLK_LOW;
		temp = data&0x80;//
		if(temp == 0x80)
		{
			DATA_HIGH;
		}
		else
		{
			DATA_LOW;
		}
		CLK_HIGH;

		data = data * 2;//tương đương data *= 2; data = data << 1; data <<=1;
	}

}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint16_t dem = 0;//sử dụng cho việc hiển thị số đếm từ 0000 - 9999
	uint8_t nghin = 0, tram = 0, chuc = 0, donvi = 0;
	uint8_t mang_led[10]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //dem = 1234;
#if 1
	  dem++;
	  if(dem >9999)dem =0;

	for(uint8_t i =0;i<100;i++)
	{
		nghin = dem/1000;//1
		tram = (dem%1000)/100;//2
		chuc = (dem%100)/10;//3
		donvi = (dem%10)/1;//4


		//Hiển thị số 1
		LAT_LOW;
		truyen8bit(mang_led[nghin]);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
		truyen8bit(0x08);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
		LAT_HIGH;
		HAL_Delay(1);

		//Hiển thị số 2
		LAT_LOW;
		truyen8bit(mang_led[tram]);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
		truyen8bit(0x04);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
		LAT_HIGH;
		HAL_Delay(1);

		//Hiển thị số 3
		LAT_LOW;
		truyen8bit(mang_led[chuc]);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
		truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
		LAT_HIGH;
		HAL_Delay(1);

		//Hiển thị số 4
		LAT_LOW;
		truyen8bit(mang_led[donvi]);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
		truyen8bit(0x01);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
		LAT_HIGH;
		HAL_Delay(1);

	}
#endif
	  #if 0
	  //Hiển thị số 0
	  LAT_LOW;
	  truyen8bit(0xC0);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x00);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 1
	  LAT_LOW;
	  truyen8bit(0xF9);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 2
	  LAT_LOW;
	  truyen8bit(0xA4);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 3
	  LAT_LOW;
	  truyen8bit(0xB0);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 4
	  LAT_LOW;
	  truyen8bit(0x99);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 5
	  LAT_LOW;
	  truyen8bit(0x92);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 6
	  LAT_LOW;
	  truyen8bit(0x82);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 7
	  LAT_LOW;
	  truyen8bit(0xF8);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 8
	  LAT_LOW;
	  truyen8bit(0x80);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);

	  //Hiển thị số 9
	  LAT_LOW;
	  truyen8bit(0x90);//lần đẩy số 1 -> vào IC2 -> điều khiển thanh
	  truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> điều khiển A not chung
	  LAT_HIGH;
	  HAL_Delay(1000);
#endif
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, DATA_Pin|CLK_Pin|LAT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DATA_Pin CLK_Pin LAT_Pin */
  GPIO_InitStruct.Pin = DATA_Pin|CLK_Pin|LAT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
