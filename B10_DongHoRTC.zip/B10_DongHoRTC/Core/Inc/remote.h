/*
 * remote.h
 *
 *  Created on: Dec 2, 2022
 *      Author: nguye
 */

#ifndef INC_REMOTE_H_
#define INC_REMOTE_H_

#include "main.h"

#define MENU 16769565
#define SO_0 16738455
#define SO_1 16724175
#define SO_2 16718055
#define SO_3 16743045
#define SO_4 16716015
#define SO_5 16726215
#define SO_6 16734885
#define SO_7 16728765
#define SO_8 16730805
#define SO_9 16732845
extern uint32_t data_remoteOK;
void remote_init(void);
#endif /* INC_REMOTE_H_ */
