/*
 * led.h
 *
 *  Created on: Dec 2, 2022
 *      Author: nguye
 */

#ifndef LED_H_
#define LED_H_
#include "main.h"

extern TIM_HandleTypeDef htim14;
extern uint16_t dem;//s dụng cho việc hiển thị số đếm từ 0000 - 9999
extern uint8_t nghin, tram, chuc, donvi;
extern uint8_t mang_led[10];
extern uint8_t so1, so2, so3, so4;
extern  uint8_t count_quet_led;


void led_init(void);
#endif /* LED_H_ */
