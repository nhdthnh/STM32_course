/*
 * led.c
 *
 *  Created on: Dec 2, 2022
 *      Author: nguye
 */
#include "led.h"
//code led 7 thanh
uint16_t dem = 1234;//sử dụng cho việc hiển thị số đếm từ 0000 - 9999
uint8_t nghin = 0, tram = 0, chuc = 0, donvi = 0;
uint8_t mang_led[10]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
uint8_t so1 = 0, so2 = 0, so3 = 0, so4 = 0;
uint8_t count_quet_led = 0;
#define DATA_HIGH HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_SET)
#define DATA_LOW HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_RESET)
#define CLK_HIGH HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_SET)
#define CLK_LOW HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_RESET)
#define LAT_HIGH HAL_GPIO_WritePin(LAT_GPIO_Port, LAT_Pin, GPIO_PIN_SET)
#define LAT_LOW HAL_GPIO_WritePin(LAT_GPIO_Port, LAT_Pin, GPIO_PIN_RESET)

void truyen8bit(uint8_t data)
{
	uint8_t temp = 0,i;

	for(i=0;i<8;i++)
	{
		CLK_LOW;
		temp = data&0x80;//
		if(temp == 0x80)
		{
			DATA_HIGH;
		}
		else
		{
			DATA_LOW;
		}
		CLK_HIGH;

		data = data * 2;//tương đương data *= 2; data = data << 1; data <<=1;
	}

}

uint16_t count_nhay = 0, nhay = 0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == htim14.Instance)
	{
		if(count_nhay>500)
		{
			count_nhay = 0;
			//500ms nó nhảy vào đây

			//phần này để đảo trạng thái của biến nháy
			if(nhay == 0)//có nghĩa là tắt dấu .
			{
				nhay = 1;
			}
			else//bật dấu .
			{
				nhay = 0;
			}
		}
		else
		{
			count_nhay ++;
		}

		//thực hiện đếm từ 0 - 3 tương ứng với hiển thị led số 1 đến led số 4
		if(count_quet_led > 3)
		{
			count_quet_led = 0;
		}
		else
		{
			count_quet_led ++;
		}

		if(count_quet_led == 0)//tương ứng hiển thị led số 1
		{
			LAT_LOW;
			truyen8bit(so1);//lần đẩy số 1 -> vào IC2 -> đi�?u khiển thanh
			truyen8bit(0x08);//lần đẩy số 2- > vào IC1 -> đi�?u khiển A not chung
			LAT_HIGH;
		}
		else if(count_quet_led == 1)//tương ứng hiển thị led số 2
		{
			LAT_LOW;
			if(nhay == 0)
			{
				truyen8bit(so2);//lần đẩy số 1 -> vào IC2 -> đi�?u khiển thanh
			}
			else
			{
				truyen8bit(so2 & 0x7F);//lần đẩy số 1 -> vào IC2 -> đi�?u khiển thanh
			}
			truyen8bit(0x04);//lần đẩy số 2- > vào IC1 -> đi�?u khiển A not chung
			LAT_HIGH;

		}
		else if(count_quet_led == 2)//tương ứng hiển thị led số 3
		{
			LAT_LOW;
			truyen8bit(so3);//lần đẩy số 1 -> vào IC2 -> đi�?u khiển thanh
			truyen8bit(0x02);//lần đẩy số 2- > vào IC1 -> đi�?u khiển A not chung
			LAT_HIGH;

		}
		else if(count_quet_led == 3)//tương ứng hiển thị led số 4
		{
			LAT_LOW;
			truyen8bit(so4);//lần đẩy số 1 -> vào IC2 -> đi�?u khiển thanh
			truyen8bit(0x01);//lần đẩy số 2- > vào IC1 -> đi�?u khiển A not chung
			LAT_HIGH;

		}

	}
}

void led_init(void)
{
	HAL_TIM_Base_Start_IT(&htim14);

	so1 = 255;
	so2 = 255;
	so3 = 255;
	so4 = 255;

}
