/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "led.h"
#include "remote.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim14;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM14_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
RTC_TimeTypeDef time_RTC;
RTC_DateTypeDef date_RTC;
uint8_t gio = 0, phut = 0, giay = 0, ngay = 0, thang = 0, nam = 0;

uint8_t mode = 0;//mode = 0 đi hiển thị giờ và phút, mode = 1 đi hiển thị cài đặt giờ, mode = 2 là hiển thị cài đặt phút

void set_time(uint8_t gio,uint8_t phut,uint8_t giay)
{
	RTC_TimeTypeDef sTime = {0};

	sTime.Hours = RTC_ByteToBcd2(gio);
	sTime.Minutes = RTC_ByteToBcd2(phut);
	sTime.Seconds = RTC_ByteToBcd2(giay);
	sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
	sTime.StoreOperation = RTC_STOREOPERATION_RESET;
	if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
	{
	Error_Handler();
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM14_Init();
  MX_RTC_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  led_init();
  remote_init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if(mode == 0) //  tương ứng hiển thị giờ phút
	  {
		  HAL_RTC_GetTime(&hrtc, &time_RTC, RTC_FORMAT_BCD);
		  HAL_RTC_GetDate(&hrtc, &date_RTC, RTC_FORMAT_BCD);

		  //chuyển đổi từ BDC sang byte
		  gio = RTC_Bcd2ToByte(time_RTC.Hours);
		  phut = RTC_Bcd2ToByte(time_RTC.Minutes);
		  giay = RTC_Bcd2ToByte(time_RTC.Seconds);

		  so1 = mang_led[gio/10];
		  so2 = mang_led[gio%10];
		  so3 = mang_led[phut/10];
		  so4 = mang_led[phut%10];
	  }
	  else if(mode == 1) //  tương ứng hiển thị giờ
	  {
		  so1 = mang_led[gio/10];
		  so2 = mang_led[gio%10];
		  so3 = 255;
		  so4 = 255;
	  }
	  else if(mode == 2) //  tương ứng hiển thị phút
	  {
		  so1 = 255;
		  so2 = 255;
		  so3 = mang_led[phut/10];
		  so4 = mang_led[phut%10];
	  }


	  //kiểm tra xem remote có nhấn không
	  if(data_remoteOK != 0)
	  {
		  //giảm tốc
		  HAL_Delay(100);
		  //nếu mà mã remote là MENU thì phải thưc hiện thay đổi biến mode
		  if(data_remoteOK == MENU)
		  {
			  if(mode >= 2)
			  {
				  mode = 0;
				  //Cần sửa thời gian
				  set_time(gio,phut,55);
			  }
			  else
			  {
				  mode ++;
			  }
		  }

		  if(data_remoteOK == SO_0)
		  {

			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 0;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 0;
			  }
		  }
		  else if(data_remoteOK == SO_1)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 1;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 1;
			  }
		  }
		  else if(data_remoteOK == SO_2)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 2;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 2;
			  }

		  }
		  else if(data_remoteOK == SO_3)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 3;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 3;
			  }

		  }
		  else if(data_remoteOK == SO_4)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 4;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 4;
			  }

		  }
		  else if(data_remoteOK == SO_5)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 5;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 5;
			  }

		  }
		  else if(data_remoteOK == SO_6)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 6;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 6;
			  }

		  }
		  else if(data_remoteOK == SO_7)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 7;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 7;
			  }

		  }
		  else if(data_remoteOK == SO_8)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 8;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 8;
			  }

		  }
		  else if(data_remoteOK == SO_9)
		  {
			  if(mode == 1)//đang cài giờ
			  {
				  gio = gio % 10;
				  gio = gio*10 + 9;
			  }
			  else if(mode == 2)//đang cài phut
			  {
				  phut = phut % 10;
				  phut = phut*10 + 9;
			  }

		  }
		  //nếu mà nhấn thì mình phải xóa giá trị cũ đi
		  data_remoteOK = 0;
	  }




  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 249;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 1599;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 9999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim4, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM14 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM14_Init(void)
{

  /* USER CODE BEGIN TIM14_Init 0 */

  /* USER CODE END TIM14_Init 0 */

  /* USER CODE BEGIN TIM14_Init 1 */

  /* USER CODE END TIM14_Init 1 */
  htim14.Instance = TIM14;
  htim14.Init.Prescaler = 15;
  htim14.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim14.Init.Period = 999;
  htim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim14) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM14_Init 2 */

  /* USER CODE END TIM14_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, DATA_Pin|CLK_Pin|LAT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DATA_Pin CLK_Pin LAT_Pin */
  GPIO_InitStruct.Pin = DATA_Pin|CLK_Pin|LAT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
