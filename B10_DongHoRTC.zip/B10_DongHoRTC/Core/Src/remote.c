/*
 * remote.c
 *
 *  Created on: Dec 2, 2022
 *      Author: nguye
 */

#include "remote.h"

extern TIM_HandleTypeDef htim4;
///nhan khiển
uint32_t data_remote = 0, data_remoteOK = 0;
uint32_t time = 0;
uint32_t MangTim[100],count = 0;

void data_process(void)
{
	//trước khi tính toán phải cho biến này = 0
	data_remote = 0;
	for(uint8_t i = 0;i<32;i++)
	{
		if(MangTim[i + 1] > 15) // nếu mà lớn hơn 15 thì nó là bit 1
		{
			data_remote = data_remote*2 + 1;
		}
		else // nếu không thì nó là bit 0
		{
			data_remote = data_remote*2;
		}
	}
	data_remoteOK = data_remote;
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim ->Instance == htim4. Instance)
	{
		//xóa count = 0
		__HAL_TIM_SET_COUNTER(&htim4,0);

		//lấy cái time
		time = __HAL_TIM_GET_COMPARE(&htim4,TIM_CHANNEL_1);

		//nhận biết được cái start of frame
		if(time > 100) count = 0;

		//cất cái time đo được vào mảng
		MangTim[count] = time;
		count ++;

		//nếu đủ 32 bit thì bắt đầu xử lý cái data nhận được
		if(count >= 32) data_process();
	}
}

void remote_init(void)
{
	//Bật timer chế độ IC
	HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_1);
}
