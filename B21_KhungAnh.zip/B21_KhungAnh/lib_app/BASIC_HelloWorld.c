/*********************************************************************
*                SEGGER MICROCONTROLLER SYSTEME GmbH                 *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2015  SEGGER Microcontroller Systeme GmbH        *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

***** emWin - Graphical user interface for embedded applications *****
emWin is protected by international copyright laws.   Knowledge of the
source code may not be used to write a similar product.  This file may
only be used in accordance with a license and should not be re-
distributed in any way. We appreciate your understanding and fairness.
----------------------------------------------------------------------
File        : BASIC_HelloWorld.c
Purpose     : Simple demo drawing "Hello world"
----------------------------------------------------------------------
*/

#include "GUI.h"
#include "main.h"
#include "DIALOG.h"
#include "stdio.h"
/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
extern WM_HWIN CreateFramewin(void);
extern WM_HWIN CreateWindow(void);
extern WM_HWIN CreateWindow_KhungAnh(void);
extern RTC_HandleTypeDef hrtc;
RTC_TimeTypeDef time;
RTC_DateTypeDef date;
#define ID_TEXT_0 (GUI_ID_USER + 0x02)
#define ID_TEXT_1 (GUI_ID_USER + 0x03)
#define ID_TEXT_2 (GUI_ID_USER + 0x04)

extern GUI_CONST_STORAGE GUI_BITMAP bm1;
extern GUI_CONST_STORAGE GUI_BITMAP bm2;
extern GUI_CONST_STORAGE GUI_BITMAP bm3;
extern GUI_CONST_STORAGE GUI_BITMAP bm4;
extern GUI_CONST_STORAGE GUI_BITMAP bm5;
#define ID_IMAGE_0 (GUI_ID_USER + 0x01)
/*********************************************************************
*
*       MainTask
*/
void MainTask(void) {
	uint16_t x = 0;
	uint16_t count_anh = 0;
	WM_HWIN hWin_KhungAnh;
	WM_HWIN      hItem;
//	GUI_SetBkColor(GUI_RED);

	GUI_Clear();
//	GUI_SetFont(&GUI_Font20_1);
//	GUI_DispStringAt("Hello world!", (LCD_GetXSize()-100)/2, (LCD_GetYSize()-20)/2);

	GUI_CURSOR_Show();
	GUI_CURSOR_SetPosition(0,0);
	GUI_CURSOR_Select(&GUI_CursorArrowL);

	hWin_KhungAnh = CreateWindow_KhungAnh();

	while(1)
	{
		GUI_Exec();
		GUI_Delay(1000);

		if(count_anh >= 4)
		{
			count_anh = 0;
		}
		else
		{
			count_anh++;
		}

		if(count_anh == 0)
		{
			hItem = WM_GetDialogItem(hWin_KhungAnh, ID_IMAGE_0);
			IMAGE_SetBitmap(hItem, &bm1);
		}
		else if(count_anh == 1)
		{
			hItem = WM_GetDialogItem(hWin_KhungAnh, ID_IMAGE_0);
			IMAGE_SetBitmap(hItem, &bm2);
		}
		else if(count_anh == 2)
		{
			hItem = WM_GetDialogItem(hWin_KhungAnh, ID_IMAGE_0);
			IMAGE_SetBitmap(hItem, &bm3);
		}
		else if(count_anh == 3)
		{
			hItem = WM_GetDialogItem(hWin_KhungAnh, ID_IMAGE_0);
			IMAGE_SetBitmap(hItem, &bm4);
		}
		else if(count_anh == 4)
		{
			hItem = WM_GetDialogItem(hWin_KhungAnh, ID_IMAGE_0);
			IMAGE_SetBitmap(hItem, &bm5);
		}
//		HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BCD);
//		HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BCD);
//		uint8_t m[32];
//		hItem = WM_GetDialogItem(hWin_Dong_ho, ID_TEXT_2);
//		sprintf(m,"%d",RTC_Bcd2ToByte(time.Seconds));
//		TEXT_SetText(hItem, m);
//
//		hItem = WM_GetDialogItem(hWin_Dong_ho, ID_TEXT_1);
//		sprintf(m,"%d",RTC_Bcd2ToByte(time.Minutes));
//		TEXT_SetText(hItem, m);
//
//		hItem = WM_GetDialogItem(hWin_Dong_ho, ID_TEXT_0);
//		sprintf(m,"%d",RTC_Bcd2ToByte(time.Hours));
//		TEXT_SetText(hItem, m);
	}
}

/*************************** End of file ****************************/
